Algoritmo FigurasGeometricas
	Definir opcion Como Entero
	Definir continuar Como Caracter
	
	Repetir
		Escribir "--- Men� de C�lculos Geom�tricos ---"
		Escribir "1. Cuadrado"
		Escribir "2. Rect�ngulo"
		Escribir "3. C�rculo"
		Escribir "4. Salir"
		Escribir "Elige una opci�n:"
		Leer opcion
		
		Si opcion <> 4 Entonces
			Segun opcion Hacer
				1:
					Definir l Como Real
					Escribir "Ingresa el lado del cuadrado:"
					Leer l
					Mientras l <= 0 Hacer
						Escribir "Error: El valor debe ser positivo. Intenta de nuevo:"
						Leer l
					FinMientras
					Escribir "�rea: ", calcular_area_cuadrado(l)
					Escribir "Per�metro: ", calcular_perimetro_cuadrado(l)
					
				2:
					Definir b, a Como Real
					Escribir "Ingresa la base:"
					Leer b
					Escribir "Ingresa la altura:"
					Leer a
					Mientras b <= 0 o a <= 0 Hacer
						Escribir "Error: Los valores deben ser positivos. Reintenta:"
						Leer b
						Leer a
					FinMientras
					Escribir "�rea: ", calcular_area_rectangulo(b, a)
					Escribir "Per�metro: ", calcular_perimetro_rectangulo(b, a)
					
				3:
					Definir r Como Real
					Escribir "Ingresa el radio del c�rculo:"
					Leer r
					Mientras r <= 0 Hacer
						Escribir "El radio debe ser mayor a 0:"
						Leer r
					FinMientras
					Escribir "�rea: ", calcular_area_circulo(r)
					Escribir "Per�metro: ", calcular_perimetro_circulo(r)
					
				De Otro Modo:
					Escribir "Opci�n no v�lida."
			Fin Segun
			
			Escribir "�Quieres hacer otro c�lculo? (s/n)"
			Leer continuar
		SiNo
			continuar <- 'n'
		Fin Si
		
	Hasta Que continuar = 'n' O continuar = 'N'
	
	Escribir "�Gracias por usar el programa!"
FinAlgoritmo

// --- FUNCIONES DEL CUADRADO ---
Funcion area <- calcular_area_cuadrado(lado)
	Definir area Como Real
	area <- lado * lado
FinFuncion

Funcion peri <- calcular_perimetro_cuadrado(lado)
	Definir peri Como Real
	peri <- 4 * lado
FinFuncion

// --- FUNCIONES DEL RECT�NGULO ---
Funcion area <- calcular_area_rectangulo(base, altura)
	Definir area Como Real
	area <- base * altura
FinFuncion

Funcion peri <- calcular_perimetro_rectangulo(base, altura)
	Definir peri Como Real
	peri <- (2 * base) + (2 * altura)
FinFuncion

// --- FUNCIONES DEL C�RCULO ---
Funcion area <- calcular_area_circulo(radio)
	Definir area Como Real
	// Usamos PI de PSeInt para m�s precisi�n
	area <- PI * (radio ^ 2)
FinFuncion

Funcion peri <- calcular_perimetro_circulo(radio)
	Definir peri Como Real
	peri <- 2 * PI * radio
FinFuncion